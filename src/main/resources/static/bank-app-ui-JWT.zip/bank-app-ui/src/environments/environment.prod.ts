export const environment = {
  production: true,
  rooturl : 'http://USHYDMAREDDY2:8080'
};

